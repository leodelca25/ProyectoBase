export const environment = {
  production: false,
  application:
  {
    name: 'angular-starter',
    angular: 'Angular 8.2.14',
    bootstrap: 'Bootstrap 4.4.1',
    fontawesome: 'Font Awesome 5.12.0',
  }
};
