export class Config {

  public api: boolean;
  public url: string;
  constructor() {
  }

}
